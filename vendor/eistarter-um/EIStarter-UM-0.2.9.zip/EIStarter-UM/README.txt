EIStarter-UM 0.2.9 - starts Evil Islands with a mod (a replacement of EIStarter).

1. Unpack this folder anywhere (it needs write access: EIStarter-UM.cfg is created here).
2. Unpack a mod (for example Universal-Mod) into its mods folder.
3. Run EIStarter-UM.exe, choose the mod, click Play.
   Linux: install the game in Lutris first, unpack this folder inside the game's prefix (e.g. drive_c/EIStarter-UM), set the game's
   executable in Lutris to EIStarter-UM.exe and start it from Lutris.
   The first time it asks for the folder of the original game if it cannot find it.
Nothing else to set up: no registry file, no DLL override. Details: docs/EIStarter-UM.md

Credits
- The look (design/), the texts (lang/), the loader (Engine/dinput.dll), addon.dll and the audio plugin mp3dec.asi of Engine/ come from EIStarter OBT-1 and the
  Evil Islands Addon engine by the EIStarter / Gipat.Ru authors (Sun, Atm, Demoth, Void Dragon, Lost Soul, Asp Adm; translations: Tyrianix, Fred,
  Peter plEI ...; addon.dll: Jet, Nivea, Holy Warrior, Sagrer, Barges, Demoth ...). Thank you.
- EIStarter-UM itself (the program, um-window.asi) is part of the Universal Mod project: https://github.com/Kyr4l/ei-universal-mod
- Engine/game.exe is the game's own executable (Nival Interactive / Fishtank Interactive) with the 4 GB (large address aware) flag set.
